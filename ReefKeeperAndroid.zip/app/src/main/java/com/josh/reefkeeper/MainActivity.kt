package com.josh.reefkeeper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONObject

private val ComponentActivity.dataStore by preferencesDataStore(name = "reef_keeper")
private val PARAMS_KEY = stringPreferencesKey("params_json")
private val TASKS_KEY = stringPreferencesKey("tasks_json")
private val NOTES_KEY = stringPreferencesKey("notes")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ReefKeeperApp(
                load = { key -> dataStore.data.firstOrNullString(key) },
                save = { key, value -> dataStore.edit { it[key] = value } }
            )
        }
    }
}

private suspend fun kotlinx.coroutines.flow.Flow<androidx.datastore.preferences.core.Preferences>.firstOrNullString(
    key: androidx.datastore.preferences.core.Preferences.Key<String>
): String = this.first()[key] ?: ""

@Composable
fun ReefKeeperApp(
    load: suspend (androidx.datastore.preferences.core.Preferences.Key<String>) -> String,
    save: suspend (androidx.datastore.preferences.core.Preferences.Key<String>, String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val bg = Color(0xFF071A23)
    val card = Color(0xFF102B36)
    val aqua = Color(0xFF54D6D0)
    var params by remember { mutableStateOf(mapOf("Salinity (SG)" to "1.025", "Temperature (°F)" to "78.0", "pH" to "8.1", "Alkalinity (dKH)" to "", "Nitrate (ppm)" to "", "Phosphate (ppm)" to "")) }
    var tasks by remember { mutableStateOf(listOf("Check temperature", "Check return pump and flow", "Top off evaporated water", "Feed fish", "Inspect fish and equipment")) }
    var completed by remember { mutableStateOf(setOf<String>()) }
    var notes by remember { mutableStateOf("") }
    var waterChange by remember { mutableStateOf("10") }
    var tankVolume by remember { mutableStateOf("120") }
    var loaded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        try {
            val p = load(PARAMS_KEY)
            if (p.isNotBlank()) {
                val obj = JSONObject(p)
                params = params.mapValues { (k, v) -> obj.optString(k, v) }
            }
            val t = load(TASKS_KEY)
            if (t.isNotBlank()) {
                val arr = org.json.JSONArray(t)
                tasks = (0 until arr.length()).map { arr.getString(it) }
            }
            notes = load(NOTES_KEY)
        } catch (_: Exception) {}
        loaded = true
    }
    LaunchedEffect(params, tasks, notes, loaded) {
        if (loaded) {
            val obj = JSONObject()
            params.forEach { (k, v) -> obj.put(k, v) }
            scope.launch { save(PARAMS_KEY, obj.toString()) }
            val arr = org.json.JSONArray()
            tasks.forEach { arr.put(it) }
            scope.launch { save(TASKS_KEY, arr.toString()) }
            scope.launch { save(NOTES_KEY, notes) }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = aqua, background = bg, surface = card,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = bg) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 18.dp, bottom = 30.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("REEF KEEPER", color = aqua, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text("Your aquarium", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("120 gal display • 30 gal sump", color = Color.LightGray)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Tank overview", color = aqua, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Text("Fish-only reef • 2 Noopsyche K7 Pro III lights")
                            Text("Current phase: Fish & coralline algae")
                            Text("RO/DI TDS target: 0–2 ppm", color = Color.LightGray)
                        }
                    }
                }
                item {
                    SectionTitle("Water parameters")
                    Text("Enter your latest test results. Values save automatically on this phone.", color = Color.LightGray)
                }
                items(params.keys.toList()) { label ->
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(label, modifier = Modifier.weight(1f))
                        OutlinedTextField(
                            value = params[label] ?: "",
                            onValueChange = { value -> params = params.toMutableMap().apply { put(label, value) } },
                            modifier = Modifier.width(130.dp),
                            singleLine = true,
                            placeholder = { Text("—") }
                        )
                    }
                }
                item {
                    SectionTitle("Daily checklist")
                    Text("${completed.size} of ${tasks.size} completed", color = aqua)
                }
                items(tasks) { task ->
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(checked = task in completed, onCheckedChange = { checked ->
                                completed = if (checked) completed + task else completed - task
                            })
                            Text(task, modifier = Modifier.weight(1f))
                        }
                    }
                }
                item {
                    OutlinedButton(onClick = { completed = emptySet() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Reset daily checklist")
                    }
                }
                item {
                    SectionTitle("Water-change calculator")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = tankVolume, onValueChange = { tankVolume = it }, label = { Text("Gallons") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = waterChange, onValueChange = { waterChange = it }, label = { Text("% change") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    val gallons = (tankVolume.toDoubleOrNull() ?: 0.0) * (waterChange.toDoubleOrNull() ?: 0.0) / 100.0
                    Text("Replace approximately ${"%.1f".format(gallons)} gallons.", color = aqua, fontWeight = FontWeight.Bold)
                }
                item {
                    SectionTitle("Tank journal")
                    OutlinedTextField(
                        value = notes, onValueChange = { notes = it },
                        modifier = Modifier.fillMaxWidth(), minLines = 4,
                        label = { Text("Observations, changes, reminders…") }
                    )
                }
                item {
                    Text("Reef Keeper • Offline data stored on this device", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(4.dp))
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}
