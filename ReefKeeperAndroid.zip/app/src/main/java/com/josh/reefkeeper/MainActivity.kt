package com.josh.reefkeeper

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.work.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Context.dataStore by preferencesDataStore(name = "reef_keeper")
private val PARAMS_KEY = stringPreferencesKey("params_json")
private val TASKS_KEY = stringPreferencesKey("tasks_json")
private val NOTES_KEY = stringPreferencesKey("notes")
private val HISTORY_KEY = stringPreferencesKey("parameter_history")
private val ACTIONS_KEY = stringPreferencesKey("action_history")
private val REMINDERS_KEY = stringPreferencesKey("reminders_json")

data class ReminderConfig(val id: String, val label: String, val enabled: Boolean, val days: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        setContent { ReefKeeperApp(this) }
    }
}

object NotificationHelper {
    const val CHANNEL = "reef_reminders"
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Reef Keeper reminders", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
    fun show(context: Context, id: String, title: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Reef Keeper reminder")
            .setContentText("Time to: $title")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(id.hashCode(), notification)
    }
}

class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val id = inputData.getString("id") ?: return Result.failure()
        val label = inputData.getString("label") ?: id
        val days = inputData.getInt("days", 3).coerceAtLeast(1)
        NotificationHelper.show(applicationContext, id, label)
        ReminderScheduler.enqueueNext(applicationContext, id, label, days)
        return Result.success()
    }
}

object ReminderScheduler {
    private fun tag(id: String) = "reef_reminder_$id"
    fun schedule(context: Context, id: String, label: String, days: Int) {
        WorkManager.getInstance(context).cancelAllWorkByTag(tag(id))
        enqueueNext(context, id, label, days)
    }
    fun enqueueNext(context: Context, id: String, label: String, days: Int) {
        val data = workDataOf("id" to id, "label" to label, "days" to days.coerceAtLeast(1))
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInputData(data)
            .addTag(tag(id))
            .setInitialDelay(days.coerceAtLeast(1).toLong(), TimeUnit.DAYS)
            .build()
        WorkManager.getInstance(context).enqueue(request)
    }
    fun cancel(context: Context, id: String) {
        WorkManager.getInstance(context).cancelAllWorkByTag(tag(id))
    }
}

private fun timestamp(): String = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()).format(Date())
private fun jsonArrayToList(raw: String): List<String> = try {
    val a = JSONArray(raw); (0 until a.length()).map { a.getString(it) }
} catch (_: Exception) { emptyList() }

@Composable
fun ReefKeeperApp(context: Context) {
    val scope = rememberCoroutineScope()
    val bg = Color(0xFF071A23)
    val card = Color(0xFF102B36)
    val aqua = Color(0xFF54D6D0)
    val paramsDefault = mapOf("Salinity (SG)" to "1.025", "Temperature (°F)" to "78.0", "pH" to "8.1", "Alkalinity (dKH)" to "", "Nitrate (ppm)" to "", "Phosphate (ppm)" to "")
    var params by remember { mutableStateOf(paramsDefault) }
    var tasks by remember { mutableStateOf(listOf("Check temperature", "Check return pump and flow", "Top off evaporated water", "Feed fish", "Inspect fish and equipment")) }
    var completed by remember { mutableStateOf(setOf<String>()) }
    var notes by remember { mutableStateOf("") }
    var waterChange by remember { mutableStateOf("10") }
    var tankVolume by remember { mutableStateOf("120") }
    var history by remember { mutableStateOf(listOf<String>()) }
    var actions by remember { mutableStateOf(listOf<String>()) }
    var reminders by remember { mutableStateOf(listOf(
        ReminderConfig("ato", "Refill ATO reservoir", true, 3),
        ReminderConfig("nori", "Feed nori", true, 3),
        ReminderConfig("flakes", "Feed flakes", true, 1),
        ReminderConfig("testing", "Test water parameters", true, 7),
        ReminderConfig("waterchange", "Perform water change", true, 14),
        ReminderConfig("tds", "Check RO/DI TDS", true, 30)
    )) }
    var loaded by remember { mutableStateOf(false) }
    var savedToast by remember { mutableStateOf("") }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        try {
            context.dataStore.data.first().let { pref ->
                val p = pref[PARAMS_KEY].orEmpty()
                if (p.isNotBlank()) {
                    val obj = JSONObject(p); params = params.mapValues { (k,v) -> obj.optString(k,v) }
                }
                val t = pref[TASKS_KEY].orEmpty()
                if (t.isNotBlank()) tasks = jsonArrayToList(t)
                notes = pref[NOTES_KEY].orEmpty()
                history = jsonArrayToList(pref[HISTORY_KEY].orEmpty())
                actions = jsonArrayToList(pref[ACTIONS_KEY].orEmpty())
                val r = pref[REMINDERS_KEY].orEmpty()
                if (r.isNotBlank()) {
                    val obj = JSONObject(r)
                    reminders = reminders.map { d -> obj.optJSONObject(d.id)?.let { ReminderConfig(d.id,d.label,it.optBoolean("enabled",d.enabled),it.optInt("days",d.days).coerceIn(1,365)) } ?: d }
                }
            }
        } catch (_: Exception) {}
        loaded = true
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun persistParams() {
        scope.launch {
            val obj = JSONObject(); params.forEach { (k,v) -> obj.put(k,v) }
            context.dataStore.edit { it[PARAMS_KEY] = obj.toString() }
        }
    }
    fun recordAction(id: String, label: String) {
        val entry = "$label — ${timestamp()}"
        actions = (listOf(entry) + actions).take(100)
        scope.launch { context.dataStore.edit { it[ACTIONS_KEY] = JSONArray(actions).toString() } }
        reminders.find { it.id == id }?.let { cfg ->
            if (cfg.enabled) ReminderScheduler.schedule(context, cfg.id, cfg.label, cfg.days)
        }
        savedToast = "Saved: $label"
    }
    fun updateReminder(updated: ReminderConfig) {
        reminders = reminders.map { if (it.id == updated.id) updated else it }
        if (updated.enabled) ReminderScheduler.schedule(context, updated.id, updated.label, updated.days)
        else ReminderScheduler.cancel(context, updated.id)
    }

    LaunchedEffect(reminders, loaded) {
        if (loaded) {
            val obj = JSONObject()
            reminders.forEach { r ->
                obj.put(r.id, JSONObject().put("enabled", r.enabled).put("days", r.days))
            }
            context.dataStore.edit { it[REMINDERS_KEY] = obj.toString() }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = aqua, background = bg, surface = card, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = bg) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 18.dp, bottom = 30.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("REEF KEEPER  •  V2", color = aqua, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text("Your aquarium", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("120 gal display • 30 gal sump", color = Color.LightGray)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Tank overview", color = aqua, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text("Fish-only reef • 2 Noopsyche K7 Pro III lights")
                            Text("Current phase: Fish & coralline algae")
                            Text("RO/DI TDS target: 0–2 ppm", color = Color.LightGray)
                        }
                    }
                }
                item {
                    SectionTitle("Quick actions")
                    Text("Tap once to log it with the current date and time.", color = Color.LightGray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { recordAction("ato", "ATO reservoir refilled") }, modifier = Modifier.weight(1f)) { Text("💧 ATO\nrefilled") }
                        Button(onClick = { recordAction("nori", "Fed nori") }, modifier = Modifier.weight(1f)) { Text("🌿 Nori") }
                        Button(onClick = { recordAction("flakes", "Fed flakes") }, modifier = Modifier.weight(1f)) { Text("🐟 Flakes") }
                    }
                    if (savedToast.isNotBlank()) Text(savedToast, color = aqua)
                    reminders.take(3).forEach { r ->
                        val last = actions.firstOrNull { it.contains(when(r.id) { "ato" -> "ATO reservoir refilled"; "nori" -> "Fed nori"; else -> "Fed flakes" }) }
                        Text("${r.label}: ${last?.substringAfter("—")?.trim() ?: "No log yet"}", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    SectionTitle("Water parameters")
                    Text("Enter readings, then save a dated snapshot for trend tracking.", color = Color.LightGray)
                }
                items(params.keys.toList()) { label ->
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(label, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = params[label] ?: "", onValueChange = { value -> params = params.toMutableMap().apply { put(label, value) } }, modifier = Modifier.width(130.dp), singleLine = true, placeholder = { Text("—") })
                    }
                }
                item {
                    Button(onClick = {
                        val row = params.entries.joinToString(" • ") { "${it.key}: ${it.value.ifBlank { "—" }}" } + " — " + timestamp()
                        history = (listOf(row) + history).take(100)
                        scope.launch {
                            val obj = JSONObject(); params.forEach { (k,v) -> obj.put(k,v) }
                            context.dataStore.edit { it[PARAMS_KEY] = obj.toString(); it[HISTORY_KEY] = JSONArray(history).toString() }
                        }
                        savedToast = "Water test snapshot saved."
                    }, modifier = Modifier.fillMaxWidth()) { Text("Save water test to history") }
                }
                item { SectionTitle("Parameter history") }
                if (history.isEmpty()) item { Text("No saved test snapshots yet.", color = Color.LightGray) }
                items(history.take(10)) { row -> Card(colors = CardDefaults.cardColors(containerColor = card)) { Text(row, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall) } }
                item {
                    SectionTitle("Daily checklist")
                    Text("${completed.size} of ${tasks.size} completed", color = aqua)
                }
                items(tasks) { task ->
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(checked = task in completed, onCheckedChange = { checked -> completed = if (checked) completed + task else completed - task })
                            Text(task, modifier = Modifier.weight(1f))
                        }
                    }
                }
                item { OutlinedButton(onClick = { completed = emptySet() }, modifier = Modifier.fillMaxWidth()) { Text("Reset daily checklist") } }
                item {
                    SectionTitle("Water-change calculator")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = tankVolume, onValueChange = { tankVolume = it }, label = { Text("Gallons") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = waterChange, onValueChange = { waterChange = it }, label = { Text("% change") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    val gallons = (tankVolume.toDoubleOrNull() ?: 0.0) * (waterChange.toDoubleOrNull() ?: 0.0) / 100.0
                    Text("Replace approximately ${"%.1f".format(gallons)} gallons.", color = aqua, fontWeight = FontWeight.Bold)
                }
                item {
                    SectionTitle("Notifications")
                    Text("Set reminders after you log the action. Android may delay background notifications.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                }
                items(reminders) { cfg ->
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text(cfg.label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                Switch(checked = cfg.enabled, onCheckedChange = { enabled -> updateReminder(cfg.copy(enabled = enabled)) })
                            }
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Every", color = Color.LightGray)
                                OutlinedTextField(value = cfg.days.toString(), onValueChange = { v -> val d = v.toIntOrNull()?.coerceIn(1,365) ?: return@OutlinedTextField; updateReminder(cfg.copy(days=d)) }, modifier = Modifier.width(80.dp), singleLine = true)
                                Text("days")
                                Spacer(Modifier.weight(1f))
                                TextButton(onClick = { if(cfg.enabled) ReminderScheduler.schedule(context,cfg.id,cfg.label,cfg.days) }) { Text("Reset timer") }
                            }
                        }
                    }
                }
                item {
                    SectionTitle("Recent activity")
                    if (actions.isEmpty()) Text("No activity logged yet.", color = Color.LightGray)
                }
                items(actions.take(15)) { entry -> Card(colors = CardDefaults.cardColors(containerColor = card)) { Text(entry, Modifier.padding(12.dp)) } }
                item {
                    SectionTitle("Tank journal")
                    OutlinedTextField(value = notes, onValueChange = { notes = it; scope.launch { context.dataStore.edit { p -> p[NOTES_KEY] = notes } } }, modifier = Modifier.fillMaxWidth(), minLines = 4, label = { Text("Observations, changes, reminders…") })
                }
                item { Text("Reef Keeper • Offline data on this phone", color = Color.Gray, style = MaterialTheme.typography.labelSmall) }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(4.dp))
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}
