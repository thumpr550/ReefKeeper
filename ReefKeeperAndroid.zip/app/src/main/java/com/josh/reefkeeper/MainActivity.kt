package com.josh.reefkeeper

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.work.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Context.dataStore by preferencesDataStore(name = "reef_keeper")
private val PARAMS_KEY = stringPreferencesKey("params_json")
private val TASKS_KEY = stringPreferencesKey("tasks_json")
private val NOTES_KEY = stringPreferencesKey("notes")
private val HISTORY_KEY = stringPreferencesKey("parameter_history")
private val ACTIONS_KEY = stringPreferencesKey("action_history")
private val REMINDERS_KEY = stringPreferencesKey("reminders_json")
private val RANGES_KEY = stringPreferencesKey("parameter_ranges_json")

data class ReminderConfig(val id: String, val label: String, val enabled: Boolean, val days: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        setContent { ReefKeeperApp(this) }
    }
}

object NotificationHelper {
    const val CHANNEL = "reef_reminders"
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Reef Keeper reminders", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }
    fun show(context: Context, id: String, title: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Reef Keeper reminder")
            .setContentText("Time to: $title")
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        context.getSystemService(NotificationManager::class.java).notify(id.hashCode(), notification)
    }
}

class ReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val id = inputData.getString("id") ?: return Result.failure()
        val label = inputData.getString("label") ?: id
        val days = inputData.getInt("days", 3).coerceAtLeast(1)
        NotificationHelper.show(applicationContext, id, label)
        ReminderScheduler.enqueueNext(applicationContext, id, label, days)
        return Result.success()
    }
}

object ReminderScheduler {
    private fun tag(id: String) = "reef_reminder_$id"
    fun schedule(context: Context, id: String, label: String, days: Int) {
        WorkManager.getInstance(context).cancelAllWorkByTag(tag(id))
        enqueueNext(context, id, label, days)
    }
    fun enqueueNext(context: Context, id: String, label: String, days: Int) {
        val data = workDataOf("id" to id, "label" to label, "days" to days.coerceAtLeast(1))
        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInputData(data)
            .addTag(tag(id))
            .setInitialDelay(days.coerceAtLeast(1).toLong(), TimeUnit.DAYS)
            .build()
        WorkManager.getInstance(context).enqueue(request)
    }
    fun cancel(context: Context, id: String) {
        WorkManager.getInstance(context).cancelAllWorkByTag(tag(id))
    }
}

private fun timestamp(): String = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()).format(Date())
private fun jsonArrayToList(raw: String): List<String> = try {
    val a = JSONArray(raw); (0 until a.length()).map { a.getString(it) }
} catch (_: Exception) { emptyList() }

@Composable
fun ReefKeeperApp(context: Context) {
    val scope = rememberCoroutineScope()
    val bg = Color(0xFF071A23)
    val card = Color(0xFF102B36)
    val aqua = Color(0xFF54D6D0)
    val paramsDefault = mapOf("Salinity (SG)" to "1.025", "Temperature (°F)" to "78.0", "pH" to "8.1", "Alkalinity (dKH)" to "", "Nitrate (ppm)" to "", "Phosphate (ppm)" to "")
    var params by remember { mutableStateOf(paramsDefault) }
    var tasks by remember { mutableStateOf(listOf("Check temperature", "Check return pump and flow", "Top off evaporated water", "Feed fish", "Inspect fish and equipment")) }
    var completed by remember { mutableStateOf(setOf<String>()) }
    var notes by remember { mutableStateOf("") }
    var waterChange by remember { mutableStateOf("10") }
    var tankVolume by remember { mutableStateOf("120") }
    var history by remember { mutableStateOf(listOf<String>()) }
    var ranges by remember { mutableStateOf(defaultParameterRanges()) }
    var graphParameter by remember { mutableStateOf("Salinity (SG)") }
    var actions by remember { mutableStateOf(listOf<String>()) }
    var reminders by remember { mutableStateOf(listOf(
        ReminderConfig("ato", "Refill ATO reservoir", true, 3),
        ReminderConfig("nori", "Feed nori", true, 3),
        ReminderConfig("flakes", "Feed flakes", true, 1),
        ReminderConfig("testing", "Test water parameters", true, 7),
        ReminderConfig("waterchange", "Perform water change", true, 14),
        ReminderConfig("filterchange", "Change/clean filter media", true, 30),
        ReminderConfig("tds", "Check RO/DI TDS", true, 30)
    )) }
    var loaded by remember { mutableStateOf(false) }
    var savedToast by remember { mutableStateOf("") }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        try {
            context.dataStore.data.first().let { pref ->
                val p = pref[PARAMS_KEY].orEmpty()
                if (p.isNotBlank()) {
                    val obj = JSONObject(p); params = params.mapValues { (k,v) -> obj.optString(k,v) }
                }
                val t = pref[TASKS_KEY].orEmpty()
                if (t.isNotBlank()) tasks = jsonArrayToList(t)
                notes = pref[NOTES_KEY].orEmpty()
                history = jsonArrayToList(pref[HISTORY_KEY].orEmpty())
                actions = jsonArrayToList(pref[ACTIONS_KEY].orEmpty())
                val rr = pref[RANGES_KEY].orEmpty()
                if (rr.isNotBlank()) {
                    val obj = JSONObject(rr); ranges = ranges.mapValues { (k,v) -> obj.optJSONObject(k)?.let { it.optDouble("min",v.first) to it.optDouble("max",v.second) } ?: v }
                }
                val r = pref[REMINDERS_KEY].orEmpty()
                if (r.isNotBlank()) {
                    val obj = JSONObject(r)
                    reminders = reminders.map { d -> obj.optJSONObject(d.id)?.let { ReminderConfig(d.id,d.label,it.optBoolean("enabled",d.enabled),it.optInt("days",d.days).coerceIn(1,365)) } ?: d }
                }
            }
        } catch (_: Exception) {}
        loaded = true
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun persistRanges() { scope.launch { val obj = JSONObject(); ranges.forEach { (k,v) -> obj.put(k, JSONObject().put("min",v.first).put("max",v.second)) }; context.dataStore.edit { it[RANGES_KEY] = obj.toString() } } }

    fun persistParams() {
        scope.launch {
            val obj = JSONObject(); params.forEach { (k,v) -> obj.put(k,v) }
            context.dataStore.edit { it[PARAMS_KEY] = obj.toString() }
        }
    }
    fun recordAction(id: String, label: String) {
        val entry = "$label — ${timestamp()}"
        actions = (listOf(entry) + actions).take(100)
        scope.launch { context.dataStore.edit { it[ACTIONS_KEY] = JSONArray(actions).toString() } }
        reminders.find { it.id == id }?.let { cfg ->
            if (cfg.enabled) ReminderScheduler.schedule(context, cfg.id, cfg.label, cfg.days)
        }
        savedToast = "Saved: $label"
    }
    fun updateReminder(updated: ReminderConfig) {
        reminders = reminders.map { if (it.id == updated.id) updated else it }
        if (updated.enabled) ReminderScheduler.schedule(context, updated.id, updated.label, updated.days)
        else ReminderScheduler.cancel(context, updated.id)
    }

    LaunchedEffect(reminders, loaded) {
        if (loaded) {
            val obj = JSONObject()
            reminders.forEach { r ->
                obj.put(r.id, JSONObject().put("enabled", r.enabled).put("days", r.days))
            }
            context.dataStore.edit { it[REMINDERS_KEY] = obj.toString() }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = aqua, background = bg, surface = card, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = bg) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 18.dp, bottom = 30.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("REEF KEEPER  •  V3", color = aqua, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text("Your aquarium", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("120 gal display • 30 gal sump", color = Color.LightGray)
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Tank overview", color = aqua, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text("Fish-only reef • 2 Noopsyche K7 Pro III lights")
                            Text("Current phase: Fish & coralline algae")
                            Text("RO/DI TDS target: 0–2 ppm", color = Color.LightGray)
                        }
                    }
                }
                item {
                    SectionTitle("Quick actions")
                    Text("Tap once to log it with the current date and time.", color = Color.LightGray)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { recordAction("ato", "ATO reservoir refilled") }, modifier = Modifier.weight(1f)) { Text("💧 ATO\nrefilled") }
                        Button(onClick = { recordAction("nori", "Fed nori") }, modifier = Modifier.weight(1f)) { Text("🌿 Nori") }
                        Button(onClick = { recordAction("flakes", "Fed flakes") }, modifier = Modifier.weight(1f)) { Text("🐟 Flakes") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(onClick = { recordAction("waterchange", "Water change") }, modifier = Modifier.weight(1f)) { Text("🪣 Water change") }
                        Button(onClick = { recordAction("filterchange", "Filter change") }, modifier = Modifier.weight(1f)) { Text("🧽 Filter change") }
                    }
                    if (savedToast.isNotBlank()) Text(savedToast, color = aqua)
                    reminders.take(3).forEach { r ->
                        val last = actions.firstOrNull { it.contains(when(r.id) { "ato" -> "ATO reservoir refilled"; "nori" -> "Fed nori"; else -> "Fed flakes" }) }
                        Text("${r.label}: ${last?.substringAfter("—")?.trim() ?: "No log yet"}", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                    }
                }
                item {
                    SectionTitle("Water parameters")
                    Text("Enter readings, then save a dated snapshot for trend tracking.", color = Color.LightGray)
                }
                items(params.keys.toList()) { label ->
                    val value = params[label].orEmpty().toDoubleOrNull()
                    val range = ranges[label] ?: parameterRange(label)
                    val statusColor = when {
                        value == null -> card
                        value < range.first || value > range.second -> Color(0xFF7A2929)
                        value < range.first + (range.second-range.first)*0.10 || value > range.second - (range.second-range.first)*0.10 -> Color(0xFF66551F)
                        else -> Color(0xFF174A35)
                    }
                    val step = parameterStep(label)
                    Card(colors = CardDefaults.cardColors(containerColor = statusColor), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp)) {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                Text("${range.first}–${range.second}", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                            }
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(onClick = {
                                    val n = (value ?: range.first) - step
                                    params = params.toMutableMap().apply { put(label, formatParameter(n, step)) }
                                }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)) { Text("−") }
                                OutlinedTextField(value = params[label] ?: "", onValueChange = { v -> params = params.toMutableMap().apply { put(label, v) } }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("—") })
                                OutlinedButton(onClick = {
                                    val n = (value ?: range.first) + step
                                    params = params.toMutableMap().apply { put(label, formatParameter(n, step)) }
                                }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)) { Text("+") }
                            }
                        }
                    }
                }
                item {
                    Button(onClick = {
                        val row = params.entries.joinToString(" • ") { "${it.key}: ${it.value.ifBlank { "—" }}" } + " — " + timestamp()
                        history = (listOf(row) + history).take(100)
                        actions = (listOf("Water test — ${timestamp()}") + actions).take(100)
                        scope.launch {
                            val obj = JSONObject(); params.forEach { (k,v) -> obj.put(k,v) }
                            context.dataStore.edit { it[PARAMS_KEY] = obj.toString(); it[HISTORY_KEY] = JSONArray(history).toString(); it[ACTIONS_KEY] = JSONArray(actions).toString() }
                        }
                        savedToast = "Water test snapshot saved."
                    }, modifier = Modifier.fillMaxWidth()) { Text("Save water test to history") }
                }
                item { SectionTitle("Parameter history") }
                item { SectionTitle("Editable target ranges")
                    Text("Adjust the green-zone limits for your tank. Changes are saved on this phone.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                }
                items(params.keys.toList()) { label ->
                    val range = ranges[label] ?: parameterRange(label)
                    Card(colors = CardDefaults.cardColors(containerColor = card)) {
                        Column(Modifier.padding(10.dp)) {
                            Text(label, fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(value = formatParameter(range.first, parameterStep(label)), onValueChange = { v -> v.toDoubleOrNull()?.let { ranges = ranges.toMutableMap().apply { put(label, it to range.second) }; persistRanges() } }, label = { Text("Minimum") }, modifier = Modifier.weight(1f), singleLine = true)
                                OutlinedTextField(value = formatParameter(range.second, parameterStep(label)), onValueChange = { v -> v.toDoubleOrNull()?.let { ranges = ranges.toMutableMap().apply { put(label, range.first to it) }; persistRanges() } }, label = { Text("Maximum") }, modifier = Modifier.weight(1f), singleLine = true)
                            }
                        }
                    }
                }
                item { SectionTitle("Parameter trends")
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        params.keys.forEach { p -> FilterChip(selected = graphParameter == p, onClick = { graphParameter = p }, label = { Text(p) }) }
                    }
                    val trend = history.reversed().mapNotNull { row ->
                        val value = Regex(Regex.escape(graphParameter) + ":\\s*([-+]?[0-9]*\\.?[0-9]+)").find(row)?.groupValues?.getOrNull(1)?.toFloatOrNull()
                        value
                    }
                    if (trend.size < 2) Text("Save at least two water-test snapshots to see a trend.", color = Color.LightGray)
                    else Canvas(Modifier.fillMaxWidth().height(170.dp)) {
                        val minV = trend.minOrNull() ?: 0f; val maxV = trend.maxOrNull() ?: 1f
                        val span = (maxV - minV).takeIf { it > 0.0001f } ?: 1f
                        val pts = trend.mapIndexed { i, v -> Offset(x = size.width * i / (trend.size - 1), y = size.height - ((v-minV)/span)*size.height) }
                        pts.zipWithNext().forEach { (a,b) -> drawLine(Color(0xFF54D6D0), a, b, strokeWidth = 4f) }
                        pts.forEach { drawCircle(Color.White, radius = 5f, center = it) }
                    }
                    if (trend.isNotEmpty()) Text("${trend.size} readings • ${trend.first()} → ${trend.last()}", color = aqua)
                }
                item { SectionTitle("Maintenance calendar / history")
                    Text("Recent logged events grouped by date (newest first).", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                }
                items(actions.groupBy { it.substringAfter("—", "No date").trim().substringBefore(" • ") }.toList()) { (date, entries) ->
                    Card(colors = CardDefaults.cardColors(containerColor = card)) {
                        Column(Modifier.padding(12.dp)) { Text(date, color = aqua, fontWeight = FontWeight.Bold); entries.forEach { Text(it.substringBefore("—").trim()) } }
                    }
                }
                item { SectionTitle("Days since last activity")
                    val activityMap = listOf("ATO reservoir refilled", "Fed nori", "Fed flakes", "Water change", "Filter change", "Water test", "RO/DI TDS")
                    activityMap.forEach { label ->
                        val last = actions.firstOrNull { it.contains(label, ignoreCase = true) }
                        val date = last?.substringAfter("—")?.trim()
                        val days = date?.let { daysSince(it) }
                        Text("$label: ${days?.let { "$it day${if(it==1) "" else "s"} ago" } ?: "Never logged"}", color = Color.LightGray)
                    }
                }

                if (history.isEmpty()) item { Text("No saved test snapshots yet.", color = Color.LightGray) }
                items(history.take(10)) { row -> Card(colors = CardDefaults.cardColors(containerColor = card)) { Text(row, Modifier.padding(12.dp), style = MaterialTheme.typography.bodySmall) } }
                item {
                    SectionTitle("Water-change calculator")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = tankVolume, onValueChange = { tankVolume = it }, label = { Text("Gallons") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(value = waterChange, onValueChange = { waterChange = it }, label = { Text("% change") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                    val gallons = (tankVolume.toDoubleOrNull() ?: 0.0) * (waterChange.toDoubleOrNull() ?: 0.0) / 100.0
                    Text("Replace approximately ${"%.1f".format(gallons)} gallons.", color = aqua, fontWeight = FontWeight.Bold)
                }
                item {
                    SectionTitle("Notifications")
                    Text("Set reminders after you log the action. Android may delay background notifications.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                }
                items(reminders) { cfg ->
                    Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text(cfg.label, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                Switch(checked = cfg.enabled, onCheckedChange = { enabled -> updateReminder(cfg.copy(enabled = enabled)) })
                            }
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Every", color = Color.LightGray)
                                OutlinedTextField(value = cfg.days.toString(), onValueChange = { v -> val d = v.toIntOrNull()?.coerceIn(1,365) ?: return@OutlinedTextField; updateReminder(cfg.copy(days=d)) }, modifier = Modifier.width(80.dp), singleLine = true)
                                Text("days")
                                Spacer(Modifier.weight(1f))
                                TextButton(onClick = { if(cfg.enabled) ReminderScheduler.schedule(context,cfg.id,cfg.label,cfg.days) }) { Text("Reset timer") }
                            }
                        }
                    }
                }
                item {
                    SectionTitle("Recent activity")
                    if (actions.isEmpty()) Text("No activity logged yet.", color = Color.LightGray)
                }
                items(actions.take(15)) { entry -> Card(colors = CardDefaults.cardColors(containerColor = card)) { Text(entry, Modifier.padding(12.dp)) } }
                item {
                    SectionTitle("Tank journal")
                    OutlinedTextField(value = notes, onValueChange = { notes = it; scope.launch { context.dataStore.edit { p -> p[NOTES_KEY] = notes } } }, modifier = Modifier.fillMaxWidth(), minLines = 4, label = { Text("Observations, changes, reminders…") })
                }
                item { Text("Reef Keeper • Offline data on this phone", color = Color.Gray, style = MaterialTheme.typography.labelSmall) }
            }
        }
    }
}

private fun defaultParameterRanges(): Map<String, Pair<Double, Double>> = mapOf("Salinity (SG)" to (1.023 to 1.026), "Temperature (°F)" to (76.0 to 79.0), "pH" to (7.8 to 8.4), "Alkalinity (dKH)" to (7.0 to 11.0), "Nitrate (ppm)" to (0.0 to 25.0), "Phosphate (ppm)" to (0.02 to 0.10))

private fun daysSince(dateText: String): Int? { return try { val fmt = SimpleDateFormat("MMM d, yyyy • h:mm a", Locale.getDefault()); val date = fmt.parse(dateText) ?: return null; ((System.currentTimeMillis()-date.time)/86400000L).toInt().coerceAtLeast(0) } catch (_: Exception) { null } }

private fun parameterStep(label: String): Double = when {
    label.contains("Salinity") -> 0.001
    label.contains("Temperature") -> 0.1
    label.contains("pH") -> 0.01
    label.contains("Alkalinity") -> 0.1
    label.contains("Phosphate") -> 0.01
    else -> 0.1
}
private fun formatParameter(value: Double, step: Double): String = when {
    step == 0.001 -> "%.3f".format(Locale.US, value)
    step == 0.01 -> "%.2f".format(Locale.US, value)
    else -> "%.1f".format(Locale.US, value)
}
private fun parameterRange(label: String): Pair<Double, Double> = when {
    label.contains("Salinity") -> 1.023 to 1.026
    label.contains("Temperature") -> 76.0 to 79.0
    label.contains("pH") -> 7.8 to 8.4
    label.contains("Alkalinity") -> 7.0 to 11.0
    label.contains("Nitrate") -> 0.0 to 25.0
    label.contains("Phosphate") -> 0.02 to 0.10
    else -> 0.0 to 100.0
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(4.dp))
    Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
}
