package com.josh.reefkeeper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val ComponentActivity.dataStore by preferencesDataStore(name = "reef_keeper")
private val TEAL = Color(0xFF42D6C5)
private val NAVY = Color(0xFF071923)
private val PANEL = Color(0xFF102A38)
private val TEXT = Color(0xFFE7F5F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReefApp(this) }
    }
}

data class Param(val name: String, val unit: String, val target: String, val key: String)
data class Task(val name: String, val frequency: String)

val params = listOf(
    Param("Temperature", "°F", "76– ใ 80", "temp"),
    Param("Salinity", "SG", "1.025–1.026", "salinity"),
    Param("pH", "", "8.1–8.4", "ph"),
    Param("Alkalinity", "dKH", "8–9", "alk"),
    Param("Nitrate", "ppm", "5–20 (reef)", "no3"),
    Param("Phosphate", "ppm", "0.03–0.10 (reef)", "po4"),
    Param("Calcium", "ppm", "400–450 (reef)", "ca"),
    Param("Magnesium", "ppm", "1250–1400 (reef)", "mg"),
    Param("Ammonia", "ppm", "0", "nh3")
)
val tasks = listOf(
    Task("Check fish and equipment", "Daily"),
    Task("Feed fish", "Daily"),
    Task("Check temperature", "Daily"),
    Task("Clean glass", "Weekly"),
    Task("Test salinity and alkalinity", "Weekly"),
    Task("Inspect pumps and skimmer", "Weekly"),
    Task("Water change", "Weekly / as needed"),
    Task("Rinse mechanical filter media", "Weekly"),
    Task("Clean return pump / powerheads", "Monthly"),
    Task("Check heater and backup plan", "Monthly")
)

@Composable
fun ReefApp(activity: MainActivity) {
    val scope = rememberCoroutineScope()
    val prefs by activity.dataStore.data.collectAsState(initial = androidx.datastore.preferences.core emptyPreferences())
    val values = remember(prefs) { params.associate { it.key to (prefs[stringPreferencesKey("param_${it.key}")] ?: "") } }
    val savedTasks = remember(prefs) { prefs[stringPreferencesKey("tasks")] ?: "" }
    val completed = remember(savedTasks) { savedTasks.split("|").filter { it.isNotBlank() }.toSet() }
    val logs = remember(prefs) { prefs[stringPreferencesKey("logs")] ?: "" }
    var tab by remember { mutableStateOf(0) }
    var selectedParam by remember { mutableStateOf<Param?>(null) }
    var input by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var showLog by remember { mutableStateOf(false) }
    var gallons by remember { mutableStateOf("10") }
    var changePct by remember { mutableStateOf("10") }
    var salt by remember { mutableStateOf("1.025") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = TEAL, background = NAVY, surface = PANEL, onBackground = TEXT,
        onSurface = TEXT, secondary = Color(0xFF8DD9F0)
    )) {
        Scaffold(
            containerColor = NAVY,
            bottomBar = {
                NavigationBar(containerColor = PANEL) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Science, null) }, label = { Text("Parameters") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Checklist, null) }, label = { Text("Tasks") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Calculate, null) }, label = { Text("Tools") })
                    NavigationBarItem(selected = tab == 4, onClick = { tab = 4 }, icon = { Icon(Icons.Default.Notes, null) }, label = { Text("Journal") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("REEF KEEPER", style = MaterialTheme.typography.labelLarge, color = TEAL, fontWeight = FontWeight.Bold)
                        Text(listOf("Tank overview", "Water parameters", "Maintenance", "Reef tools", "Tank journal")[tab], style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                    Text("120 GAL", color = TEAL, fontWeight = FontWeight.Bold)
                }
                when (tab) {
                    0 -> HomeScreen(values, completed, onTab = { tab = it })
                    1 -> ParameterScreen(values, onEdit = { selectedParam = it; input = values[it.key] })
                    2 -> TaskScreen(completed) { task, checked ->
                        val next = if (checked) completed + task else completed - task
                        scope.launch { activity.dataStore.edit { it[stringPreferencesKey("tasks")] = next.joinToString("|") } }
                    }
                    3 -> ToolsScreen(gallons, { gallons = it }, changePct, { changePct = it }, salt, { salt = it })
                    else -> JournalScreen(logs, note, { note = it }, showLog, { showLog = it }) {
                        val entry = "${System.currentTimeMillis()}|$note"
                        scope.launch { activity.dataStore.edit { it[stringPreferencesKey("logs")] = (logs + "\n" + entry).trim() } }
                        note = ""; showLog = false
                    }
                }
            }
        }
        selectedParam?.let { p ->
            AlertDialog(
                onDismissRequest = { selectedParam = null },
                title = { Text("Log ${p.name}") },
                text = {
                    Column {
                        Text("Target: ${p.target}")
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(input, { input = it }, label = { Text("Value ${p.unit}") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                    }
                },
                confirmButton = { TextButton(onClick = {
                    scope.launch { activity.dataStore.edit { it[stringPreferencesKey("param_${p.key}")] = input } }
                    selectedParam = null
                }) { Text("Save") } },
                dismissButton = { TextButton(onClick = { selectedParam = null }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = PANEL), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun HomeScreen(values: Map<String, String>, completed: Set<String>, onTab: (Int) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item {
            CardBox {
                Text("Your aquarium", color = TEAL, fontWeight = FontWeight.Bold)
                Text("120-gallon reef • Fish-only phase", style = MaterialTheme.typography.titleLarge)
                Text("Oceanic display • 30g sump • Noopsyche K7 Pro III ×2", color = Color.LightGray)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip("Fish", "7")
                    StatChip("Sump", "30 gal")
                    StatChip("RO TDS", "1–2")
                }
            }
        }
        item {
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Maintenance checklist", fontWeight = FontWeight.Bold)
                        Text("${completed.size} of ${tasks.size} tasks checked", color = Color.LightGray)
                    }
                    TextButton(onClick = { onTab(2) }) { Text("Open") }
                }
                LinearProgressIndicator(progress = { completed.size.toFloat() / tasks.size }, modifier = Modifier.fillMaxWidth(), color = TEAL)
            }
        }
        item {
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Latest water readings", fontWeight = FontWeight.Bold)
                        Text("Tap Parameters to log your next test", color = Color.LightGray)
                    }
                    TextButton(onClick = { onTab(1) }) { Text("Log") }
                }
                params.take(4).forEach { p ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(p.name)
                        Text(values[p.key].takeUnless { it.isNullOrBlank() }?.let { "$it ${p.unit}" } ?: "—", color = TEAL)
                    }
                }
            }
        }
        item { Text("Reminder: manual logging only. This app does not connect to aquarium sensors.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)) }
    }
}

@Composable
fun StatChip(label: String, value: String) {
    Surface(color = Color(0xFF173B4A), shape = RoundedCornerShape(10.dp)) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
            Text(value, color = TEAL, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ParameterScreen(values: Map<String, String>, onEdit: (Param) -> Unit) {
    LazyColumn {
        item { Text("Tap a parameter to save a reading. Values are stored on this phone.", color = Color.LightGray, modifier = Modifier.padding(bottom = 8.dp)) }
        items(params) { p ->
            CardBox {
                Row(Modifier.fillMaxWidth().clickable { onEdit(p) }, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Text("Target: ${p.target}", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(values[p.key].takeUnless { it.isNullOrBlank() }?.let { "$it ${p.unit}" } ?: "Not logged", color = TEAL)
                        Text("Tap to edit", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun TaskScreen(completed: Set<String>, onCheck: (String, Boolean) -> Unit) {
    LazyColumn {
        item { Text("Mark tasks complete as you go. Checks are saved locally.", color = Color.LightGray, modifier = Modifier.padding(bottom = 8.dp)) }
        items(tasks) { task ->
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = task.name in completed, onCheckedChange = { onCheck(task.name, it) })
                    Column(Modifier.weight(1f)) {
                        Text(task.name, fontWeight = FontWeight.SemiBold)
                        Text(task.frequency, style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                    }
                }
            }
        }
    }
}

@Composable
fun ToolsScreen(gallons: String, setGallons: (String) -> Unit, pct: String, setPct: (String) -> Unit, salinity: String, setSalinity: (String) -> Unit) {
    LazyColumn {
        item {
            CardBox {
                Text("Water-change calculator", fontWeight = FontWeight.Bold)
                Text("Display volume estimate: 120 gallons (actual system volume may be lower).")
                OutlinedTextField(gallons, setGallons, label = { Text("Water to make (gallons)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(pct, setPct, label = { Text("Percent of 120g tank") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                val result = ((pct.toDoubleOrNull() ?: 0.0) * 120.0 / 100.0)
                Text("Water change: %.1f gallons".format(result), color = TEAL, fontWeight = FontWeight.Bold)
                Divider()
                Text("Salt mix helper", fontWeight = FontWeight.Bold)
                OutlinedTextField(salinity, setSalinity, label = { Text("Target specific gravity") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Text("Mix to the salt manufacturer’s instructions, then verify SG with a calibrated refractometer. Salt amount varies by brand.", color = Color.LightGray)
            }
        }
        item {
            CardBox {
                Text("Quick notes", fontWeight = FontWeight.Bold)
                Text("• Mix replacement water to match tank temperature and salinity.\n• Use RO/DI water; your reported TDS was 1–2 ppm.\n• Avoid sudden salinity corrections; adjust gradually.")
            }
        }
    }
}

@Composable
fun JournalScreen(logs: String, note: String, setNote: (String) -> Unit, showLog: Boolean, setShowLog: (Boolean) -> Unit, save: () -> Unit) {
    LazyColumn {
        item {
            CardBox {
                Text("Tank journal", fontWeight = FontWeight.Bold)
                OutlinedTextField(note, setNote, label = { Text("Observation, maintenance, livestock, etc.") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                Button(onClick = save, enabled = note.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Save journal entry") }
            }
        }
        item {
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Saved entries", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { setShowLog(!showLog) }) { Text(if (showLog) "Hide" else "Show") }
                }
                if (showLog) {
                    if (logs.isBlank()) Text("No journal entries yet.")
                    else logs.split("\n").filter { it.isNotBlank() }.reversed().forEach { line ->
                        val parts = line.split("|", limit = 2)
                        Text(parts.getOrElse(1) { line }, modifier = Modifier.padding(vertical = 6.dp))
                        Divider()
                    }
                }
            }
        }
    }
}
